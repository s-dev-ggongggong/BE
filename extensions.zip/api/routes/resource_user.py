# File: api/routes/employee.py

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required
from api.services import target_service
from utils.api_error_handlers import api_errorhandler
from utils.http_status_handler import handle_response, not_found, bad_request, server_error
from utils.api_error_handlers import api_errorhandler

resource_bp = Blueprint('resource_bp', __name__)

@api_errorhandler(resource_bp)
def handle_api_error(error):
    return jsonify({"error": str(error)}), 500

@resource_bp.route('/', methods=['GET'])
def get_users():
    users, status = target_service.get_all_users()
    return handle_response(status, data=users, message="Employees retrieved successfully")

@resource_bp.route('/<int:id>', methods=['GET'])
def get_user(id):
    user, status = target_service.get_user_by_id(id)
    if status == 404:
        return not_found(f"Employee with ID {id} not found")
    return handle_response(status, data=user, message="Employee retrieved successfully")

@resource_bp.route('/', methods=['POST'])
def add_user():
    data = request.get_json()
    if not data:
        return bad_request("Request body is empty")
    user, status = target_service.create_user(data)
    return handle_response(status, data=user, message="Employee created successfully")
 

 
@resource_bp.route('/admin', methods=['POST'])
def add_user():
    data = request.get_json()
    if not data:
        return bad_request("Request body is empty")
    user, status = target_service.create_user(data)
    return handle_response(status, data=user, message="Employee created successfully")
 