# File: api/routes/__init__.py

from . import target_user
from . import resource_user
from . import email
from . import training
from . import department
from . import role
from . import event_log
from . import auth_token