# File: api/services/resources_service.py

from models.resource_user import Resources
from extensions import db
from sqlalchemy.exc import SQLAlchemyError
from models.schemas import resources_schema
from models.init import 
from utils.http_status_handler import handle_response ,server_error
from flask_jwt_extended import create_access_token

def get_all_users():
    try:
        users = Resources.query.all()
        result = [
            {
                "id": user.id,
                "name": user.name,
                "email": user.email,
                "department_name": user.department_name,
                "role_name": user.role_name,
                "admin_id" :user.admin_id,
                "admin_pw": user.admin_pw
            }
            for user in users
        ]
        return result, 200
    except SQLAlchemyError as e:
        return {"error": str(e)}, 500

def get_user_by_id(user_id):
    try:
        user = Resources.query.get_or_404(user_id)
        return {
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "department_name": user.department_name,
            "role_name": user.role_name,
             "admin_id" :user.admin_id,
            "admin_pw": user.admin_pw
        }, 200
    except SQLAlchemyError as e:
        return {"error": str(e)}, 500

def create_user(data):
    try:
        new_user = Resources(
            name=data['name'],
            email=data['email'],
            password=data['password'],  # Consider hashing this
            department_name=data['department_name'],
            role_name=data['role_name']
        )
        db.session.add(new_user)
        db.session.commit()
        return {"message": "Resources created", "user": {"id": new_user.id, "name": new_user.name}}, 201
    except SQLAlchemyError as e:
        db.session.rollback()
        return {"error": str(e)}, 500

    
ADMIN_PASSWORD = "igloo1234"

def get_admin_user():
    try:
        admin = Resources.query.filter_by(role_name="SYSTEM_ADMIN").first()
        if not admin:
            return {"error": "Admin user not found"}, 404
        
        return {
            "id": admin.id,
            "name": admin.name,
            "email": admin.email,
            "department_name": admin.department_name,
            "role_name": admin.role_name,
            'admin_id':admin.admin_id,
            'admin_pw':admin.admin_pw
        }, 200
    except SQLAlchemyError as e:
        return {"error": str(e)}, 500

def admin_login(email, password):
    try:
        admin = Resources.query.filter_by(role_name="SYSTEM_ADMIN", email=email).first()
        if not admin or password != ADMIN_PASSWORD:
            return {"error": "Invalid credentials"}, 401
        
        access_token = create_access_token(identity=admin.id)
        return {
            "access_token": access_token,
            "user": {
                "id": admin.id,
                "name": admin.name,
                "email": admin.email,
                "department_name": admin.department_name,
                "role_name": admin.role_name
            }
        }, 200
    except SQLAlchemyError as e:
        return {"error": str(e)}, 500