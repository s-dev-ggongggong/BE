# File: api/__init__.py
from flask import Blueprint, redirect, jsonify

api_bp = Blueprint('api', __name__)

# Import routes after creating the blueprint to avoid circular imports

from api.routes.target_user import  target_bp
from api.routes.resource_user import  resource_bp
from api.routes.email import  email_bp
from api.routes.training import  training_bp
from api.routes.department import  department_bp
from api.routes.role import  role_bp
from api.routes.event_log import  event_log_bp

 
# def index():
#     return redirect('/swagger')

def init_routes():
    routes = [
 
        (target_bp, '/tuser'),
        (resource_bp, '/ruser')
        (email_bp, '/email'),
        (training_bp, '/training'),
        (department_bp, '/department'),
        (role_bp, '/role'),
        (event_log_bp, '/eventlog'),
    ]

    for route_blueprint, url_prefix in routes:
        api_bp.register_blueprint(route_blueprint, url_prefix=url_prefix)

# Initialize routes
init_routes()