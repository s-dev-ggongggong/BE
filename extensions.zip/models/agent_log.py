from extensions import db

class AgentLog(db.Model):
    __tablename__ = 'agent_logs'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    timestamp = db.Column(db.DateTime, default=db.func.current_timestamp())
    process = db.Column(db.String(100), nullable=False)
    message = db.Column(db.Text, nullable=False)

    def __repr__(self):
        return f'<AgentLog {self.id}: {self.process}>'