from marshmallow import fields, validates, ValidationError,validates_schema, pre_load, post_dump
from extensions import ma, db
from models.department import Department
from models.role import Role
from models.target_user import Targets
from models.resource_user import Resources
 
from models.training import Training
from models.email import Email

from models.event_log import EventLog
from models.delete_train import DeletedTraining
from datetime import datetime
# Base Schema
class Base(ma.SQLAlchemyAutoSchema):
    class Meta:
        include_fk = True
        load_instance = True
        sqla_session = db.session

# Define schemas with data_key for camelCaseem
class DepartmentSchema(Base):
    id = fields.Int(data_key="id",dump_only=True)
    name = fields.Str(data_key="name",dump_only=True),
    code1 = fields.Str(data_key="code1")
    code2 = fields.Str(data_key="code2")
    korean_name = fields.Str(data_key="koreanName")
    description = fields.Str(data_key="description")
    dept_target = fields.List(fields.Str(), data_key="deptTarget")


    @pre_load
    def process_targets(self, data, **kwargs):
        if 'deptTarget' in data and isinstance(data['deptTarget'], list):
            data['dept_target'] = ','.join(data['deptTarget'])
        return data

    @post_dump
    def process_targets_dump(self, data, **kwargs):
        if 'dept_target' in data and isinstance(data['dept_target'], str):
            data['deptTarget'] = data['dept_target'].split(',')
        return data
    
    class Meta(Base.Meta):
        model = Department

class RoleSchema(Base):
        id = fields.Int(data_key="id")
        name = fields.Str(data_key="name")
        korean_name = fields.Str(data_key="koreanName")
        class Meta(Base.Meta):
            model = Role


class ResourceUserSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Resources
        include_fk = True
        load_instance = True

    department_name = fields.Str(data_key="departmentName")
    role_name = fields.Str(data_key="roleName")
    admin_id = fields.Str(data_key="adminId")
    admin_pw = fields.Str(data_key="adminPw", load_only=True)

class TargetUserSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Targets
        include_fk = True
        load_instance = True

    department_name = fields.Str(data_key="departmentName")
    role_name = fields.Str(data_key="roleName")

class TrainingSchema(Base):
    id = fields.Int(dump_only=True)
    training_name = fields.Str(data_key="trainingName")
    training_desc = fields.Str(data_key="trainingDesc")
    training_start = fields.DateTime(data_key="trainingStart", format='%Y-%m-%d %H:%M:%S')
    training_end = fields.DateTime(data_key="trainingEnd",format='%Y-%m-%d %H:%M:%S')
    resource_user = fields.Int(data_key="resourceUser")
    max_phishing_mail = fields.Int(data_key="maxPhishingMail")
    
    # Use lists here since you're receiving arrays in the JSON
    dept_target = fields.List(fields.Str(), data_key="deptTarget")
    role_target = fields.List(fields.Str(), data_key="roleTarget")
 
    created_at = fields.DateTime(dump_only=True,format='%Y-%m-%d %H:%M:%S')
    is_finished = fields.Bool(dump_only=True)
    status = fields.Str(dump_only=True)
   
    class Meta(Base.Meta):
        model = Training
      


class DeletedTrainingSchema(Base):
    id = fields.Int(dump_only=True)
    original_id = fields.Int(required=True)
    training_name = fields.Str(data_key="trainingName", required=True)
    training_desc = fields.Str(data_key="trainingDesc", required=True)
    training_start = fields.DateTime(data_key="trainingStart", format='%Y-%m-%d %H:%M:%S')
    training_end = fields.DateTime(data_key="trainingEnd", format='%Y-%m-%d %H:%M:%S')
    resource_user = fields.Int(data_key="resourceUser", required=True)
    max_phishing_mail = fields.Int(data_key="maxPhishingMail", required=True)
    dept_target = fields.List(fields.Str(), data_key="deptTarget")
    role_target = fields.List(fields.Str(), data_key="roleTarget")


    created_at = fields.DateTime(dump_only=True,format='%Y-%m-%d %H:%M:%S')
    is_finished = fields.Boolean()
    status = fields.Str()
    deleted_at = fields.DateTime(dump_only=True,format='%Y-%m-%d %H:%M:%S')

    class Meta(Base.Meta):
        model = DeletedTraining
 
class EmailSchema(Base):
    id = fields.Int(data_key="id")
    subject = fields.Str(data_key="subject")
    body = fields.Str(data_key="body")
    sender = fields.Str(data_key="sender")
    recipient = fields.Str(data_key="recipient") 
    sent_date = fields.DateTime(data_key="sentDate",format='%Y-%m-%d %H:%M:%S')
    class Meta(Base.Meta):
        model = Email

 

class EventLogSchema(Base):
    id = fields.Int(dump_only=True)
    action = fields.Str(allow_none=True)
    timestamp = fields.DateTime(format='%Y-%m-%d %H:%M:%S')
    training_id = fields.Int(allow_none=True)
    message = fields.Str(allow_none=True)

    @validates('action')
    def validate_action(self, value):
        if value not in [None, "", "targetSetting"]:
            raise ValidationError("Action must be null, empty string, or 'targetSetting'")

    class Meta(Base.Meta):
        model = EventLog
       

# Schema instances for direct usage
department_schema = DepartmentSchema()
departments_schema = DepartmentSchema(many=True)
role_schema = RoleSchema()
roles_schema = RoleSchema(many=True)
resource_user_schema = ResourceUserSchema()
resource_users_schema = ResourceUserSchema(many=True)
target_user_schema = TargetUserSchema()
target_users_schema = TargetUserSchema(many=True)

training_schema = TrainingSchema()
trainings_schema = TrainingSchema(many=True)
email_schema = EmailSchema()
emails_schema = EmailSchema(many=True)

event_log_schema = EventLogSchema()
event_logs_schema = EventLogSchema(many=True)
deleted_training_schema = DeletedTrainingSchema()
deleted_trainings_schema = DeletedTrainingSchema(many=True)
# Export all schemas
__all__ = [
    'department_schema', 'departments_schema',
    'role_schema', 'roles_schema',
    'training_schema', 'trainings_schema',
    'email_schema', 'emails_schema',
    'auth_token_schema', 'auth_tokens_schema',
    'event_log_schema', 'event_logs_schema'
]
