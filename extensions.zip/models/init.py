from models.department import Department
from models.role import Role
from models.resource_user import Resources
from models.training import Training
from models.email import Email
from models.delete_train import DeletedTraining
from models.event_log import EventLog
from models.target_user import Targets
 
__all__ = [
    'Department', 'Role',  'Targets','Resources',
 'Training', 'Email', 'EventLog' ,'DeletedTraining' ,
 
]