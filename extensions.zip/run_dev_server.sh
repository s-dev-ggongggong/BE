#!/bin/bash
export FLASK_APP=app.py
export FLASK_ENV=development
export PYTHONPATH="/c/Users/ww3ys/OneDrive/바탕 화면/BE"

flask run --port 8000
