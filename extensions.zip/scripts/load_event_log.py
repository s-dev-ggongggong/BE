import sys
import os
import json
from datetime import datetime
from sqlalchemy.exc import SQLAlchemyError, IntegrityError
from sqlalchemy.orm.exc import FlushError

# 프로젝트 루트 경로 설정
project_root = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, project_root)

from app import create_app
from extensions import db
from models.event_log import EventLog

def parse_timestamp(timestamp_str):
    try:
        # Try parsing with milliseconds
        return datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S.%f')
    except ValueError:
        try:
            # If that fails, try parsing without milliseconds
            return datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            # If both fail, return None
            print(f"Invalid timestamp format: {timestamp_str}")
            return None

def is_duplicate(session, action, timestamp, training_id):
    existing = session.query(EventLog).filter_by(
        action=action,
        timestamp=timestamp,
        training_id=training_id
    ).first()
    return existing is not None

def load_event_logs():
    app = create_app()
    with app.app_context():
        try:
            file_path = os.path.join(project_root, 'data', 'event_logs.json')
            with open(file_path, 'r', encoding='utf-8') as file:
                logs_data = json.load(file)

            successful_inserts = 0
            duplicates = 0
            validation_errors = 0

            for log in logs_data:
                timestamp = parse_timestamp(log.get('timestamp', ''))
                if timestamp:
                    action = log.get('action', '')
                    training_id = log.get('trainingId')
                    message = log.get('message', '')

                    if is_duplicate(db.session, action, timestamp, training_id):
                        duplicates += 1
                        print(f"Skipping duplicate entry: action={action}, timestamp={timestamp}, training_id={training_id}")
                        continue

                    try:
                        event_log = EventLog(
                            action=action,
                            timestamp=timestamp,
                            training_id=training_id,
                            message=message
                        )
                        db.session.add(event_log)
                        db.session.flush()  # This will check for validation errors
                        successful_inserts += 1
                    except (IntegrityError, FlushError) as e:
                        db.session.rollback()
                        validation_errors += 1
                        print(f"Validation error: {e}")

            db.session.commit()
            print(f"Successfully loaded {successful_inserts} event logs")
            print(f"Skipped {duplicates} duplicate entries")
            print(f"Encountered {validation_errors} validation errors")
        except FileNotFoundError:
            print("event_logs.json file not found")
        except json.JSONDecodeError:
            print("Error decoding event_logs.json")
        except SQLAlchemyError as e:
            db.session.rollback()
            print(f"Database error: {e}")
        except Exception as e:
            print(f"Unexpected error: {e}")

if __name__ == "__main__":
    load_event_logs()